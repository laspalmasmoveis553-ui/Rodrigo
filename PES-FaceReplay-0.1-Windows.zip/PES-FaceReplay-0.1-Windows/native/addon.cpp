// PES FaceReplay 0.1: explicit still-replay capture, no per-frame neural call.
#include <windows.h>
#include <reshade.hpp>
#include <filesystem>
#include <fstream>
#include <memory>
#include <mutex>
#include <unordered_map>
#include <vector>
#include <cmath>
#include "protocol.hpp"
namespace fs=std::filesystem;
using namespace reshade::api;
static fs::path base;
struct Bridge {
 HANDLE mapping=nullptr, mutex=nullptr;
 uint8_t *bytes=nullptr;
 uint32_t width=0,height=0,request=0;
 bool active=false,pending=false,waiting=false,clear_pending=false;
 ULONGLONG started=0,shown=0;
 float roi[4]={0,0,1,1};
 ~Bridge() {
  if(mutex && bytes) {
   const auto r=WaitForSingleObject(mutex,0);
   if(r==WAIT_OBJECT_0 || r==WAIT_ABANDONED) {header().state=face::closed;ReleaseMutex(mutex);}
  }
  if(bytes)UnmapViewOfFile(bytes);
  if(mapping)CloseHandle(mapping);
  if(mutex)CloseHandle(mutex);
 }
 face::Header &header() {return *reinterpret_cast<face::Header *>(bytes);}
 uint8_t *input(){return bytes+64;}
 uint8_t *output(){return input()+face::pixels(width,height);}
};
static std::unordered_map<effect_runtime *,std::unique_ptr<Bridge>> bridges;
static std::mutex contexts;
static ULONGLONG last_channel=0;
static void message(const char *s) {reshade::log::message(reshade::log::level::info,s);}
struct TryLock {
 HANDLE h;bool locked;
 explicit TryLock(HANDLE x):h(x),locked(false) {if(h){DWORD r=WaitForSingleObject(h,0);locked=r==WAIT_OBJECT_0 || r==WAIT_ABANDONED;}}
 ~TryLock(){if(locked)ReleaseMutex(h);}
};
static void init(effect_runtime *rt) {
 try {
  if(rt->get_device()->get_api()!=device_api::d3d11)return;
  uint32_t w,h;rt->get_screenshot_width_and_height(&w,&h);
  if(!face::dimensions(w,h)) {message("FaceReplay: resolution outside 320x240..3840x2160.");return;}
  const auto fmt=rt->get_device()->get_resource_desc(rt->get_current_back_buffer()).texture.format;
  // capture_screenshot returns native format. Only SDR RGBA8 is supported.
  if(fmt!=format::r8g8b8a8_unorm && fmt!=format::r8g8b8a8_unorm_srgb) {message("FaceReplay: requires SDR RGBA8 back buffer.");return;}
  std::lock_guard<std::mutex> lock(contexts);
  if(!bridges.empty())return; // One game swapchain/channel, never ambiguous mixing.
  auto b=std::make_unique<Bridge>();b->width=w;b->height=h;
  const auto now=GetTickCount64();last_channel=now>last_channel?now:last_channel+1;
  const auto name=L"Local\\PESFaceReplay1-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(last_channel);
  b->mutex=CreateMutexW(nullptr,FALSE,(name+L"-mutex").c_str());
  const auto size=64+2*face::pixels(w,h);
  b->mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,DWORD(size),name.c_str());
  if(!b->mutex || !b->mapping) {message("FaceReplay: cannot create local IPC.");return;}
  b->bytes=static_cast<uint8_t *>(MapViewOfFile(b->mapping,FILE_MAP_ALL_ACCESS,0,0,size));
  if(!b->bytes) {message("FaceReplay: cannot map local IPC.");return;}
  face::initialize(b->header(),w,h);
  fs::create_directories(base/L"PESFaceReplayData");
  auto tmp=base/L"PESFaceReplayData/bridge.tmp";
  // Name contains ASCII only; JSON needs escaped backslash.
  std::string ascii(name.begin(),name.end());ascii.replace(5,1,"\\\\");
  std::ofstream out(tmp,std::ios::binary|std::ios::trunc);
  out<<"{\"version\":1,\"pid\":"<<GetCurrentProcessId()<<",\"width\":"<<w<<",\"height\":"<<h<<",\"name\":\""<<ascii<<"\"}";out.close();
  if(!out || !MoveFileExW(tmp.c_str(),(base/L"PESFaceReplayData/bridge.json").c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)) {message("FaceReplay: cannot announce channel; check folder write permissions.");return;}
  bridges.emplace(rt,std::move(b));
  message("FaceReplay ready: enable PESFaceReplay LAST. Paused closeup: Ctrl+F8 capture; Ctrl+F9 clear. Start INICIAR_ROSTOS.cmd.");
 } catch(...) {message("FaceReplay: initialization failed; effect remains inactive.");}
}
static void destroy(effect_runtime *rt) {std::lock_guard<std::mutex> lock(contexts);bridges.erase(rt);}
static void reload(effect_runtime *rt) {
 std::lock_guard<std::mutex> lock(contexts);auto it=bridges.find(rt);if(it==bridges.end())return;
 auto &b=*it->second;b.active=false;b.pending=false;b.waiting=false;b.clear_pending=true;
}
static void begin(effect_runtime *rt,command_list *,resource_view,resource_view) {
 std::lock_guard<std::mutex> lock(contexts);auto it=bridges.find(rt);if(it==bridges.end())return;
 auto &b=*it->second;
 const bool control=rt->is_key_down(VK_CONTROL);
 if(control && rt->is_key_pressed(VK_F9)) {b.active=false;b.pending=false;b.waiting=false;b.clear_pending=true;message("FaceReplay cleared.");}
 if(control && rt->is_key_pressed(VK_F8)) {b.active=false;b.pending=true;b.waiting=false;b.clear_pending=true;}
 if(b.waiting && GetTickCount64()-b.started>15000) {b.waiting=false;b.clear_pending=true;message("FaceReplay: request timed out. Check worker console.");}
 if(b.active && GetTickCount64()-b.shown>30000) {b.active=false;message("FaceReplay: still image expired after 30 seconds. Capture again if still paused.");}
 if(auto v=rt->find_uniform_variable("PESFaceReplay.fx","FCReady");v.handle)rt->set_uniform_value_bool(v,b.active);
 if(auto v=rt->find_uniform_variable("PESFaceReplay.fx","FCGeneration");v.handle)rt->set_uniform_value_float(v,float(b.request));
 if(auto v=rt->find_uniform_variable("PESFaceReplay.fx","FCRoi");v.handle)rt->set_uniform_value_float(v,b.roi,4);
}
static void finish(effect_runtime *rt,command_list *,resource_view,resource_view) {
 try {
  std::lock_guard<std::mutex> lock(contexts);auto it=bridges.find(rt);if(it==bridges.end())return;
  auto &b=*it->second;TryLock lockipc(b.mutex);if(!lockipc.locked)return;
  auto &h=b.header();if(!face::valid(h) || h.width!=b.width || h.height!=b.height)return;
  if(b.clear_pending) {face::cancel(h);b.request=h.request;b.clear_pending=false;}
  if(!b.pending && !b.waiting)return;
  auto source=rt->find_texture_variable("PESFaceReplay.fx","FCSource");
  auto result=rt->find_texture_variable("PESFaceReplay.fx","FCResult");
  auto technique=rt->find_technique("PESFaceReplay.fx","PESFaceReplay");
  if(!source.handle || !result.handle || !technique.handle || !rt->get_technique_state(technique)) {
   b.pending=false;b.waiting=false;face::cancel(h);message("FaceReplay: enable PESFaceReplay technique and place LAST in effect order.");return;
  }
  if(b.pending) {
   b.pending=false;
   uint32_t w,y;rt->get_screenshot_width_and_height(&w,&y);
   if(w!=b.width || y!=b.height)return;
   if(!rt->capture_screenshot(b.input())) {message("FaceReplay: capture failed.");return;}
   ++h.request;b.request=h.request;h.state=face::requested;h.error=0;b.waiting=true;b.started=GetTickCount64();
   message("FaceReplay: snapshot sent. Keep replay PAUSED; one face will be processed.");return;
  }
  if(h.state==face::failed && h.request==b.request) {b.waiting=false;h.state=face::idle;message("FaceReplay: worker rejected image or GPU error. See results/latest.json and worker console.");return;}
  if(face::accept(h,b.request)) {
   for(float v:h.roi)if(!std::isfinite(v) || v<0 || v>1) {b.waiting=false;h.state=face::idle;return;}
   if(h.roi[0]>=h.roi[2] || h.roi[1]>=h.roi[3]) {b.waiting=false;h.state=face::idle;return;}
   rt->update_texture(source,b.width,b.height,b.input());
   rt->update_texture(result,b.width,b.height,b.output());
   std::memcpy(b.roi,h.roi,sizeof(b.roi));b.active=true;b.waiting=false;b.shown=GetTickCount64();h.state=face::idle;
   message("FaceReplay: GFPGAN result uploaded. Motion guard can suppress it. Ctrl+F9 clears.");
  }
 }catch(...) {reload(rt);message("FaceReplay: capture/upload error; disabled.");}
}
extern "C" {
__declspec(dllexport) const char *NAME="PES FaceReplay 0.1";
__declspec(dllexport) const char *DESCRIPTION="GFPGAN paused replay bridge. Ctrl+F8 capture, Ctrl+F9 clear. Not live match processing.";
}
BOOL APIENTRY DllMain(HMODULE module,DWORD reason,LPVOID) {
 if(reason==DLL_PROCESS_ATTACH) {
  wchar_t path[32768];DWORD n=GetModuleFileNameW(module,path,32768);if(!n || n>=32768)return FALSE;
  base=fs::path(path).parent_path();
  if(!reshade::register_addon(module))return FALSE;
  reshade::register_event<reshade::addon_event::init_effect_runtime>(init);
  reshade::register_event<reshade::addon_event::destroy_effect_runtime>(destroy);
  reshade::register_event<reshade::addon_event::reshade_reloaded_effects>(reload);
  reshade::register_event<reshade::addon_event::reshade_begin_effects>(begin);
  reshade::register_event<reshade::addon_event::reshade_finish_effects>(finish);
 }else if(reason==DLL_PROCESS_DETACH)reshade::unregister_addon(module);
 return TRUE;
}
