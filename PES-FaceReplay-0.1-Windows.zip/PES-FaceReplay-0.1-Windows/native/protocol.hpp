#pragma once
#include <cstdint>
#include <cstring>
#include <cstddef>
namespace face {
constexpr uint32_t version = 1;
enum State : uint32_t { idle, requested, processing, ready, failed, closed };
struct Header {
 char magic[8];
 uint32_t version, width, height, state, request, result, error, reserved;
 float roi[4];
 uint32_t pad[2];
};
static_assert(sizeof(Header)==64);
static_assert(offsetof(Header,roi)==40);
inline bool dimensions(uint32_t w,uint32_t h) {return w>=320 && h>=240 && w<=3840 && h<=2160;}
inline size_t pixels(uint32_t w,uint32_t h) {return size_t(w)*h*4;}
inline void initialize(Header &h,uint32_t w,uint32_t y) {
 h={};std::memcpy(h.magic,"PESFACE1",8);h.version=version;h.width=w;h.height=y;
}
inline bool valid(const Header &h) {return std::memcmp(h.magic,"PESFACE1",8)==0 && h.version==version && dimensions(h.width,h.height) && h.state<=closed;}
inline void cancel(Header &h) {++h.request;h.state=idle;h.error=0;}
inline bool accept(const Header &h,uint32_t request) {return h.state==ready && h.request==request && h.result==request;}
}
