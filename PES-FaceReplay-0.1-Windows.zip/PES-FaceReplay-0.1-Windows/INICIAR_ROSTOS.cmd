@echo off
setlocal
cd /d "%~dp0"
"python\python.exe" -I "engine\launch.py"
set "RESULT=%ERRORLEVEL%"
echo.
pause
exit /b %RESULT%
