// FaceReplay 0.1 - compositor only. GFPGAN inference runs in the separate worker.
// Place this technique LAST, use a PAUSED replay closeup. Ctrl+F9 before resuming.
uniform bool FCReady < hidden = true; > = false;
uniform float FCGeneration < hidden = true; > = 0;
uniform float4 FCRoi < hidden = true; > = float4(0,0,1,1);
texture2D FCBack : COLOR;
sampler2D FCBackS { Texture = FCBack; };
texture2D FCSource { Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA8; };
texture2D FCResult { Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA8; };
sampler2D FCSourceS { Texture = FCSource; };
sampler2D FCResultS { Texture = FCResult; };
texture2D FCDifference { Width = 32; Height = 32; Format = RG16F; MipLevels = 6; };
sampler2D FCDifferenceS { Texture = FCDifference; MinFilter = LINEAR; MagFilter = LINEAR; MipFilter = LINEAR; };
texture2D FCLatch { Width = 1; Height = 1; Format = RG32F; };
texture2D FCHistory { Width = 1; Height = 1; Format = RG32F; };
sampler2D FCLatchS { Texture = FCLatch; };
sampler2D FCHistoryS { Texture = FCHistory; };
void FCVS(uint id : SV_VertexID, out float4 pos : SV_Position, out float2 uv : TEXCOORD) {
 uv=float2((id<<1)&2,id&2); pos=float4(uv*float2(2,-2)+float2(-1,1),0,1);
}
float FCDelta(float2 uv) {return dot(abs(tex2D(FCBackS,uv).rgb-tex2D(FCSourceS,uv).rgb),float3(0.333333,0.333333,0.333333));}
float2 FCDifferencePS(float4 pos:SV_Position,float2 uv:TEXCOORD):SV_Target {
 if(!FCReady)return 0;
 return float2(FCDelta(uv),FCDelta(lerp(FCRoi.xy,FCRoi.zw,uv)));
}
float2 FCLatchPS(float4 pos:SV_Position,float2 uv:TEXCOORD):SV_Target {
 if(!FCReady)return float2(0,-1);
 float2 prev=tex2D(FCHistoryS,float2(.5,.5)).rg;
 float2 err=tex2Dlod(FCDifferenceS,float4(.5,.5,0,5)).rg;
 bool fresh=abs(prev.y-FCGeneration)>.25;
 bool good=err.x<.018 && err.y<.022;
 return float2(good && (fresh || prev.x>.5) ? 1.0 : 0.0,FCGeneration);
}
float2 FCCopyPS(float4 pos:SV_Position,float2 uv:TEXCOORD):SV_Target {return tex2D(FCLatchS,uv).rg;}
float4 FCComposePS(float4 pos:SV_Position,float2 uv:TEXCOORD):SV_Target {
 float4 current=tex2D(FCBackS,uv);
 if(!FCReady || tex2D(FCLatchS,float2(.5,.5)).r<.5)return current;
 float4 result=tex2D(FCResultS,uv);
 float3 delta=abs(current.rgb-tex2D(FCSourceS,uv).rgb);
 float local=max(delta.x,max(delta.y,delta.z));
 float alpha=result.a*(1-smoothstep(.025,.08,local));
 return float4(lerp(current.rgb,result.rgb,alpha),current.a);
}
technique PESFaceReplay < ui_label = "PES FaceReplay - GFPGAN (replay PAUSADO)";
 ui_tooltip = "Coloque por ultimo. Inicie INICIAR_ROSTOS.cmd. Ctrl+F8 captura; Ctrl+F9 limpa. Use close pausado, um rosto. Nao acompanha movimento."; > {
 pass Difference { VertexShader = FCVS; PixelShader = FCDifferencePS; RenderTarget = FCDifference; GenerateMipMaps = true; }
 pass Guard { VertexShader = FCVS; PixelShader = FCLatchPS; RenderTarget = FCLatch; }
 pass Remember { VertexShader = FCVS; PixelShader = FCCopyPS; RenderTarget = FCHistory; }
 pass Compose { VertexShader = FCVS; PixelShader = FCComposePS; }
}
