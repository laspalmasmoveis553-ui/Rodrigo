import unittest,tempfile,sys,json,hashlib
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'engine'))
import numpy as np
from faces import similarity,CANONICAL,compose,align,choose_face,Neural
from protocol import *
import install
class ProtocolTests(unittest.TestCase):
 def make(self):return [b'PESFACE1',1,1920,1080,REQUESTED,3,0,0,0,0.,0.,1.,1.,0,0]
 def test_layout_and_bounds(self):
  h=self.make();self.assertEqual(HEADER.size,64);self.assertEqual(decode(HEADER.pack(*h),1920,1080),h)
  for w,hgt in [(0,1080),(3841,1080),(1920,2161)]:self.assertFalse(dimensions(w,hgt))
  h[1]=2
  with self.assertRaises(ValueError):decode(HEADER.pack(*h),1920,1080)
 def test_announcement(self):
  d={'name':'Local\\PESFaceReplay1-42-77','pid':42,'version':1,'width':1920,'height':1080}
  self.assertEqual(announcement(d),64+1920*1080*8)
  for change in [{'pid':43},{'name':'Global\\evil'},{'width':99999},{'version':2}]:
   with self.assertRaises(ValueError):announcement(dict(d,**change))
 def test_stale_cancel_error_closed(self):
  h=self.make();h[4]=PROCESSING;self.assertTrue(publishable(h,3))
  self.assertFalse(publishable(h,2))
  for state in [IDLE,READY,FAILED,CLOSED]:h[4]=state;self.assertFalse(publishable(h,3))
  h[4]=PROCESSING;h[5]=4;self.assertFalse(publishable(h,3))
class ImageTests(unittest.TestCase):
 def test_similarity_known_transform(self):
  src=(CANONICAL-np.array([12,-30]))/1.8;m=similarity(src)
  np.testing.assert_allclose(src@m[:,:2].T+m[:,2],CANONICAL,atol=1e-9)
  with self.assertRaises(ValueError):similarity(np.zeros((5,2)))
  with self.assertRaises(ValueError):similarity(np.ones((5,2))*float('nan'))
 def test_mask_preserves_hud_and_frame(self):
  image=np.full((512,512,3),40,np.uint8);face=np.full_like(image,200)
  rgba,out,roi=compose(image,face,np.array([[1.,0,0],[0,1.,0]]))
  self.assertTrue(np.all(out[rgba[:,:,3]==0]==40))
  self.assertTrue(np.all(out[285,256]==200));self.assertEqual(rgba[285,256,3],255)
  self.assertTrue(np.all(out[:50]==40));self.assertTrue(0<roi[0]<roi[2]<1)
  np.testing.assert_array_equal(align(image,np.array([[1.,0,0],[0,1.,0]])),image)
 def test_outside_face_rejected(self):
  with self.assertRaises(ValueError):compose(np.zeros((512,512,3),np.uint8),np.zeros((512,512,3),np.uint8),np.array([[1.,0,99999],[0,1.,99999]]))
 def test_no_face_is_rejected(self):
  model=Path(__file__).resolve().parents[1]/'models/yunet.onnx'
  with self.assertRaisesRegex(ValueError,'Nenhum rosto'):
   choose_face(np.full((240,320,3),100,np.uint8),model)
 def test_gpu_unavailable_never_falls_back(self):
  with patch('torch.cuda.is_available',return_value=False):
   with self.assertRaisesRegex(RuntimeError,'CUDA indisponivel'):
    Neural('unused-checkpoint',device='cuda')
class InstallerTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)/'package';self.game=Path(self.temp.name)/'game';self.root.mkdir();self.game.mkdir()
  (self.root/'Assets').mkdir()
  for name in ['PESFaceReplay.addon64','PESFaceReplay.fx']:(self.root/'Assets'/name).write_bytes(name.encode())
  (self.game/'dxgi.dll').write_bytes(b'user reshade');(self.game/'preset.ini').write_bytes(b'user preset')
 def tearDown(self):self.temp.cleanup()
 def test_install_repeat_remove_preserves_user(self):
  self.assertTrue(install.install(self.game,self.root));self.assertFalse(install.install(self.game,self.root));install.uninstall(self.game)
  self.assertEqual((self.game/'dxgi.dll').read_bytes(),b'user reshade');self.assertEqual((self.game/'preset.ini').read_bytes(),b'user preset')
  self.assertFalse((self.game/'PESFaceReplay.addon64').exists())
 def test_existing_file_preserved(self):
  p=self.game/'PESFaceReplay.addon64';p.write_bytes(b'user')
  with self.assertRaises(ValueError):install.install(self.game,self.root)
  self.assertEqual(p.read_bytes(),b'user')
 def test_modified_file_blocks_all_removal(self):
  install.install(self.game,self.root);(self.game/'reshade-shaders/Shaders/PESFaceReplay.fx').write_bytes(b'custom')
  with self.assertRaises(ValueError):install.uninstall(self.game)
  self.assertTrue((self.game/'PESFaceReplay.addon64').exists())
 def test_symlink_escape(self):
  outside=Path(self.temp.name)/'outside';outside.mkdir();(self.game/'reshade-shaders').symlink_to(outside,target_is_directory=True)
  with self.assertRaises(ValueError):install.install(self.game,self.root)
  self.assertFalse((self.game/'PESFaceReplay.addon64').exists())
 def test_rollback(self):
  original=Path.open
  def fail(p,*args,**kwargs):
   if p.name=='PESFaceReplay.fx' and args and args[0]=='xb':raise OSError('disk failure fixture')
   return original(p,*args,**kwargs)
  with patch.object(Path,'open',fail):
   with self.assertRaises(OSError):install.install(self.game,self.root)
  self.assertFalse((self.game/'PESFaceReplay.addon64').exists())
 def test_manifest_write_failure_rolls_back(self):
  def fail(data,f,**kwargs):
   f.write('{');raise OSError('manifest write failure fixture')
  with patch.object(install.json,'dump',fail):
   with self.assertRaises(OSError):install.install(self.game,self.root)
  self.assertFalse((self.game/install.MANIFEST).exists())
  self.assertFalse((self.game/'PESFaceReplay.addon64').exists())
  self.assertFalse((self.game/'reshade-shaders/Shaders/PESFaceReplay.fx').exists())
if __name__=='__main__':unittest.main()
