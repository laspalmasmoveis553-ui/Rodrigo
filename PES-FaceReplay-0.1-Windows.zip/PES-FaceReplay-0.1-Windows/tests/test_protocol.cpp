#include "../native/protocol.hpp"
#include <cassert>
int main(){face::Header h;face::initialize(h,1920,1080);assert(face::valid(h));assert(face::pixels(1920,1080)==8294400);h.request=5;h.result=5;h.state=face::ready;assert(face::accept(h,5));assert(!face::accept(h,4));face::cancel(h);assert(h.request==6 && h.state==face::idle);assert(!face::accept(h,5));h.width=99999;assert(!face::valid(h));h.width=1920;h.version=2;assert(!face::valid(h));return 0;}
