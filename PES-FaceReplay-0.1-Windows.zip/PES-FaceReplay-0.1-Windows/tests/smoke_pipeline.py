from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'engine'))
import numpy as np
from PIL import Image,ImageDraw
from faces import Neural
from worker import process
source=Path(sys.argv[1]);checkpoint=Path(sys.argv[2]);dest=Path(sys.argv[3]);dest.mkdir(parents=True,exist_ok=True)
rgb=np.array(Image.open(source).convert('RGB'))
n=Neural(checkpoint,device='cpu')
rgba,result,aligned,restored,roi,report=process(rgb,n)
assert result.shape==rgb.shape and rgba.shape==(*rgb.shape[:2],4)
np.testing.assert_array_equal(result[rgba[:,:,3]==0],rgb[rgba[:,:,3]==0])
assert report['status']=='completed' and report['device']=='cpu' and not report['game_60fps_validated']
Image.fromarray(result).save(dest/'resultado-cpu.png')
Image.fromarray(rgba).save(dest/'mascara-cpu.png')
canvas=Image.new('RGB',(1024,560),(25,28,32));canvas.paste(Image.fromarray(aligned),(0,48));canvas.paste(Image.fromarray(restored),(512,48))
draw=ImageDraw.Draw(canvas);draw.text((12,8),'ENTRADA - alinhamento automatico YuNet',fill='white');draw.text((524,8),'GFPGAN 100% - previa CPU offline',fill='white');draw.text((12,27),'FaceReplay: esta imagem NAO comprova execucao dentro do PES.',fill='white')
canvas.save(dest/'previa-cpu.png')
report['input_sha256']=hashlib.sha256(source.read_bytes()).hexdigest();report['shader_applied']=False;report['windows_addon_executed']=False
(dest/'smoke.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
