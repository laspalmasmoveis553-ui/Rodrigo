"""CPU reference of the shader's mip-average guard and local rejection.
Checks the mathematical policy; does not claim GPU shader execution.
"""
from pathlib import Path
import numpy as np
s=(Path(__file__).resolve().parents[1]/'Assets/PESFaceReplay.fx').read_text()
# Tie reference tests to the exact source predicates/constants being evaluated.
for term in ['if(!FCReady)return float2(0,-1);','err.x<.018 && err.y<.022','abs(prev.y-FCGeneration)>.25','fresh || prev.x>.5','smoothstep(.025,.08,local)','MipLevels = 6','GenerateMipMaps = true']:assert term in s

def guard(active,generation,previous,err):
 if not active:return (0,-1)
 good=err[0]<.018 and err[1]<.022
 return (float(good and (abs(previous[1]-generation)>.25 or previous[0]>.5)),generation)
state=guard(False,2,(1,1),(0,0));assert state==(0,-1)
state=guard(True,2,state,(0,0));assert state==(1,2) # first result activates
state=guard(True,2,state,(0.001,.006));assert state==(1,2) # small numeric variation
state=guard(True,2,state,(.002,.1));assert state==(0,2) # face moves, global unchanged
state=guard(True,2,state,(0,0));assert state==(0,2) # cannot resurrect stale face
state=guard(True,3,state,(0,0));assert state==(1,3) # explicit new snapshot
state=guard(True,3,state,(.8,.0));assert state==(0,3) # cut elsewhere
assert guard(True,4,(0,-1),(.1,.1))==(0,4) # camera moved during inference
assert guard(False,4,(1,4),(0,0))==(0,-1) # F9/reload/expiry
# Six-level 32px mip average equals global mean for 2x2 linear box reduction.
x=np.random.default_rng(0).uniform(size=(32,32,2)).astype(np.float32);m=x.copy()
for i in range(5):m=m.reshape(m.shape[0]//2,2,m.shape[1]//2,2,2).mean(axis=(1,3))
np.testing.assert_allclose(m[0,0],x.mean(axis=(0,1)),atol=1e-6)
print('Guard policy: activation, face/camera motion, stale latch, explicit refresh, disabled/reset, mip reduction passed (CPU reference).')
