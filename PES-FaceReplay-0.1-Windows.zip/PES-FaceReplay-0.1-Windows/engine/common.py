from pathlib import Path
import hashlib,json,os,urllib.request
ROOT=Path(__file__).resolve().parents[1]
MODEL_URL='https://github.com/TencentARC/GFPGAN/releases/download/v1.3.0/GFPGANv1.4.pth'
MODEL_SHA='e2cd4703ab14f4d01fd1383a8a8b266f9a5833dacee8e6a79d3bf21a1b6be5ad'
MODEL_BYTES=348632874
MODEL=ROOT/'models/GFPGANv1.4.pth'
def sha256(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def write_json(path,data):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8');os.replace(tmp,path)
def download_checked(url,destination,expected_hash,expected_size,opener=urllib.request.urlopen):
 destination=Path(destination)
 if destination.exists():
  if destination.stat().st_size==expected_size and sha256(destination)==expected_hash:return False
  raise RuntimeError('Arquivo existente nao corresponde ao modelo oficial: '+str(destination)+'. Renomeie-o para preservar e tente novamente.')
 destination.parent.mkdir(parents=True,exist_ok=True)
 partial=destination.with_suffix(destination.suffix+'.partial')
 h=hashlib.sha256();count=0;last=0
 try:
  with opener(url,timeout=60) as response,partial.open('wb') as f:
   while True:
    block=response.read(1024*1024)
    if not block:break
    count+=len(block)
    if count>expected_size:raise RuntimeError('Download maior que o arquivo esperado.')
    f.write(block);h.update(block)
    if count-last>=32*1024*1024:
     print('Modelo: %.0f / %.0f MiB'%(count/1048576,expected_size/1048576),flush=True);last=count
  if count!=expected_size or h.hexdigest()!=expected_hash:raise RuntimeError('Download incompleto ou SHA256 incorreto. Nao sera executado.')
  os.replace(partial,destination)
 except BaseException:
  partial.unlink(missing_ok=True);raise
 return True
