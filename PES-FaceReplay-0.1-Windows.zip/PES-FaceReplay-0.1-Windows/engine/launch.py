"""Explicit private paths; the earlier FaceLab remains the source of CUDA/model files."""
from pathlib import Path
import sys,json,subprocess,traceback
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'engine'))
def main():
 if sys.platform!='win32' or sys.version_info[:2]!=(3,11):raise RuntimeError('Use INICIAR_ROSTOS.cmd no Windows64.')
 config=json.loads((ROOT/'settings.json').read_text(encoding='utf-8'))
 if config.get('version')!=1:raise ValueError('Configuracao invalida; execute INSTALAR_NO_PES.cmd.')
 previous=Path(config['facelab'])
 site=previous/'python/Lib/site-packages'
 if not site.is_dir():raise FileNotFoundError('Pasta do FaceLab anterior foi movida. Preserve-a para reutilizar CUDA e pesos.')
 sys.path.append(str(site))
 from importlib.metadata import version
 for package,wanted in [('torch','2.5.1+cu124'),('numpy','1.26.4'),('Pillow','10.4.0')]:
  if version(package)!=wanted:raise RuntimeError('Versao inesperada de '+package+' no FaceLab anterior.')
 try:has_cv=version('opencv-python-headless')=='4.10.0.84'
 except Exception:has_cv=False
 if not has_cv:
  print('Preparando detector facial local (OpenCV, aprox.40MB). Reutilizando CUDA e GFPGAN do teste anterior.',flush=True)
  subprocess.run([sys.executable,'-I','-m','pip','--isolated','--disable-pip-version-check','install','--no-cache-dir','--only-binary=:all:','--no-deps','--upgrade','--target',str(ROOT/'python/Lib/site-packages'),'--index-url','https://pypi.org/simple','opencv-python-headless==4.10.0.84'],check=True)
  from importlib import invalidate_caches
  invalidate_caches()
 from worker import main as worker
 worker(config)
if __name__=='__main__':
 try:main()
 except KeyboardInterrupt:print('Worker encerrado. Ctrl+F9 no jogo limpa o resultado imediatamente.')
 except Exception as e:
  from common import write_json
  write_json(ROOT/'results/startup-error.json',{'status':'failed','error':str(e),'trace':traceback.format_exc()})
  print('ERRO: '+str(e)+'\nDiagnostico em results/startup-error.json',flush=True);sys.exit(1)
