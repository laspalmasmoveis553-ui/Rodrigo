"""Versioned bounded snapshot mailbox. Every access must hold the named mutex."""
import struct,re
HEADER=struct.Struct('<8s8I4f2I')
IDLE,REQUESTED,PROCESSING,READY,FAILED,CLOSED=range(6)
def dimensions(w,h):return 320<=w<=3840 and 240<=h<=2160

def announcement(data):
 if data.get('version')!=1 or not dimensions(data.get('width',0),data.get('height',0)):raise ValueError('Canal/dimensoes invalidos.')
 if not re.fullmatch(r'Local\\PESFaceReplay1-[0-9]+-[0-9]+',data.get('name','')):raise ValueError('Nome de canal invalido.')
 if data['name'].split('-')[1]!=str(data.get('pid')):raise ValueError('PID inconsistente.')
 return 64+data['width']*data['height']*8

def decode(raw,width,height):
 v=list(HEADER.unpack(raw))
 if v[0]!=b'PESFACE1' or v[1]!=1 or v[2]!=width or v[3]!=height or not dimensions(width,height) or v[4] not in range(6):raise ValueError('Cabecalho invalido.')
 return v

def publishable(header,request):return header[4]==PROCESSING and header[5]==request
