"""One explicit snapshot request; no screen polling, background capture or uploads."""
from pathlib import Path
import json,time,datetime,traceback,ctypes,hashlib
import numpy as np
from PIL import Image
from common import ROOT,write_json
from protocol import REQUESTED,PROCESSING,READY,FAILED,CLOSED,publishable
from winchannel import Channel
from faces import choose_face,align,compose,Neural

def process(rgb,neural):
 t=time.perf_counter();matrix,info=choose_face(rgb,ROOT/'models/yunet.onnx')
 aligned=align(rgb,matrix);restored,report=neural.infer(aligned)
 rgba,blended,roi=compose(rgb,restored,matrix)
 report.update(info);report.update({'worker_total_ms':(time.perf_counter()-t)*1000,'scope':'one explicit paused-replay snapshot; no tracking/live-match validation','roi':roi,'strength':1.0,'mask':'feathered face oval;100% inside','status':'completed'})
 return rgba,blended,aligned,restored,roi,report

def main(config):
 # Windows local named mutex prevents two workers from sharing the same GPU/channel.
 k=ctypes.WinDLL('kernel32',use_last_error=True)
 k.CreateMutexW.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_wchar_p];k.CreateMutexW.restype=ctypes.c_void_p
 k.CloseHandle.argtypes=[ctypes.c_void_p];k.CloseHandle.restype=ctypes.c_int
 game=Path(config['game']);key=hashlib.sha256(str(game.resolve()).lower().encode()).hexdigest()[:24]
 singleton=k.CreateMutexW(None,False,'Local\\PESFaceReplayWorker-'+key)
 if not singleton:raise OSError('Falha no mutex do worker.')
 if ctypes.get_last_error()==183:k.CloseHandle(singleton);raise RuntimeError('Ja existe um worker aberto para este jogo.')
 channel=None
 try:
  print('Carregando GFPGAN100% na GPU. Mantenha esta janela aberta.',flush=True)
  neural=Neural(Path(config['facelab'])/'models/GFPGANv1.4.pth')
  print('Pronto. Abra o PES. Em CLOSE DE REPLAY PAUSADO, Ctrl+F8 processa um rosto; Ctrl+F9 limpa. Ctrl+C encerra este worker.',flush=True)
  last_name=None;last_notice=None
  while True:
   try:
    data=json.loads((game/'PESFaceReplayData/bridge.json').read_text())
    if channel is None or data['name']!=last_name:
     if channel:channel.close();channel=None
     channel=Channel(data);last_name=data['name'];last_notice=None;print('Conectado ao PES: '+str(data['width'])+'x'+str(data['height']),flush=True)
    with channel.locked():
     h=channel.header()
     if h[4]==CLOSED:raise OSError('Jogo encerrou/recriou o canal.')
     if h[4]!=REQUESTED:
      request=None
     else:
      request=h[5];raw=channel.input();h[4]=PROCESSING;channel.write_header(h)
    if request is None:time.sleep(.05);continue
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f');folder=ROOT/'results'/stamp;folder.mkdir(parents=True)
    print('Processando captura '+str(request)+'...',flush=True)
    try:
     rgb=np.frombuffer(raw,np.uint8).reshape(data['height'],data['width'],4)[:,:,:3].copy();del raw
     rgba,blended,aligned,restored,roi,report=process(rgb,neural)
     Image.fromarray(rgb).save(folder/'entrada.png');Image.fromarray(blended).save(folder/'resultado.png')
     Image.fromarray(np.concatenate([aligned,restored],axis=1)).save(folder/'comparacao-rosto.png')
     with channel.locked():
      h=channel.header();sent=publishable(h,request)
      if sent:
       channel.output(rgba.tobytes());h[6]=request;h[9:13]=roi;h[4]=READY;channel.write_header(h)
     report['published_to_game']=sent
     print('Resultado enviado ao ReShade.' if sent else 'Captura cancelada/antiga; resultado descartado pelo canal.',flush=True)
    except Exception as e:
     report={'status':'failed','error':str(e),'trace':traceback.format_exc(),'published_to_game':False,'game_60fps_validated':False}
     try:
      with channel.locked():
       h=channel.header()
       if publishable(h,request):h[4]=FAILED;h[7]=1;channel.write_header(h)
     except Exception:pass
     print('Falha: '+str(e),flush=True)
     neural.torch.cuda.empty_cache()
    report['request']=request;report['channel']=data['name'];write_json(folder/'relatorio.json',report);write_json(ROOT/'results/latest.json',report)
   except (OSError,ValueError,KeyError) as e:
    if channel:channel.close();channel=None
    notice=str(e)
    if notice!=last_notice:print('Aguardando PES/addon: '+notice,flush=True);last_notice=notice
    time.sleep(1)
 finally:
  if channel:channel.close()
  k.CloseHandle(singleton)
