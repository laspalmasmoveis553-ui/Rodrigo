"""Additive, reversible installation. Never writes dxgi.dll or a ReShade preset."""
from pathlib import Path
import json,hashlib,shutil,sys,os
ROOT=Path(__file__).resolve().parents[1]
FILES={'Assets/PESFaceReplay.addon64':'PESFaceReplay.addon64','Assets/PESFaceReplay.fx':'reshade-shaders/Shaders/PESFaceReplay.fx'}
MANIFEST='PESFaceReplayData/install.json'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def safe(game,relative):
 p=game/relative
 if not p.resolve().is_relative_to(game.resolve()):raise ValueError('Destino aponta para fora da pasta do jogo: '+str(p))
 return p

def install(game,root=ROOT):
 game=Path(game).resolve();manifest=safe(game,MANIFEST)
 wanted={rel:digest(root/src) for src,rel in FILES.items()}
 if manifest.exists():
  old=json.loads(manifest.read_text(encoding='utf-8'))
  if old.get('owner')!='PESFaceReplay-0.1' or old.get('files')!=wanted:raise ValueError('Instalacao existente diferente. Preserve seus arquivos; remova a versao anterior pelo instalador correspondente.')
  if any(not safe(game,r).is_file() or digest(safe(game,r))!=h for r,h in wanted.items()):raise ValueError('Arquivo instalado foi alterado. Nao sera sobrescrito.')
  return False
 for rel in wanted:
  if safe(game,rel).exists():raise ValueError('Arquivo ja existe, preservado: '+str(game/rel))
 made=[];manifest_created=False
 try:
  for src,rel in FILES.items():
   p=safe(game,rel);p.parent.mkdir(parents=True,exist_ok=True)
   with p.open('xb') as f:
    made.append(p);f.write((root/src).read_bytes())
  manifest.parent.mkdir(parents=True,exist_ok=True)
  with manifest.open('x',encoding='utf-8') as f:
   manifest_created=True;json.dump({'owner':'PESFaceReplay-0.1','files':wanted},f,indent=2)
 except BaseException:
  if manifest_created:manifest.unlink(missing_ok=True)
  for p in reversed(made):p.unlink(missing_ok=True)
  raise
 return True

def uninstall(game):
 game=Path(game).resolve();manifest=safe(game,MANIFEST)
 if not manifest.exists():raise ValueError('Manifesto de instalacao ausente; nada removido.')
 data=json.loads(manifest.read_text(encoding='utf-8'))
 if data.get('owner')!='PESFaceReplay-0.1' or set(data.get('files',{}))!=set(FILES.values()):raise ValueError('Manifesto desconhecido; nada removido.')
 # Preflight all hashes so a customized file never causes unrelated deletions.
 for rel,h in data['files'].items():
  p=safe(game,rel)
  if p.exists() and digest(p)!=h:raise ValueError('Arquivo modificado preservado: '+str(p))
 for rel in data['files']:
  p=safe(game,rel)
  if p.exists():p.unlink()
 manifest.unlink()
 # Generated bridge announcement is deliberately left as harmless diagnostic state.

def ask_path(prompt):return Path(input(prompt+'\n> ').strip().strip('"')).expanduser().resolve()
def main():
 if '--remove' in sys.argv:
  data=json.loads((ROOT/'settings.json').read_text(encoding='utf-8'))
  print('Feche o PES e o worker antes de remover.');input('Enter para continuar: ')
  uninstall(Path(data['game']));print('Addon e shader removidos. Seus presets e DLLs do jogo foram preservados.');return
 print('PES FaceReplay 0.1: instalacao para CLOSE DE REPLAY PAUSADO. Feche o jogo.')
 game=ask_path('Cole a pasta do jogo que contem PES2021.exe ou FL_2026.exe:')
 if not any(p.is_file() and (p.name.lower()=='pes2021.exe' or (p.name.lower().startswith('fl') and p.suffix.lower()=='.exe')) for p in game.iterdir()):raise ValueError('Executavel PES/Football Life nao encontrado nesta pasta.')
 if not (game/'dxgi.dll').is_file():raise ValueError('ReShade dxgi.dll nao encontrado. Use a instalacao ReShade6.8 com suporte a addons que voce ja possui.')
 old=ask_path('Cole a pasta extraida do PES-FaceLab-0.1-Windows que voce usou no teste de GPU:')
 from common import sha256,MODEL_SHA
 if not (old/'python/Lib/site-packages/torch').is_dir():raise ValueError('Bibliotecas do teste anterior nao encontradas nessa pasta.')
 if sha256(old/'models/GFPGANv1.4.pth')!=MODEL_SHA:raise ValueError('Modelo anterior nao corresponde ao aprovado.')
 config={'version':1,'game':str(game),'facelab':str(old)}
 config_path=ROOT/'settings.json'
 if config_path.exists() and json.loads(config_path.read_text(encoding='utf-8'))!=config:raise ValueError('Este pacote ja esta configurado para outras pastas. Extraia uma nova copia para outra instalacao.')
 # Write local configuration before game mutation, to avoid an untracked install if the package is read-only.
 from common import write_json
 write_json(config_path,config)
 install(game)
 print('Instalado. Inicie INICIAR_ROSTOS.cmd e mantenha a janela aberta. No ReShade, habilite PESFaceReplay e mova para ULTIMO. Ctrl+F8 captura um close pausado; Ctrl+F9 remove.')
if __name__=='__main__':
 try:main()
 except Exception as e:print('ERRO: '+str(e));sys.exit(1)
