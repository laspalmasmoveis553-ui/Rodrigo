"""Local face detection/alignment and the approved GFPGAN, one still at a time."""
from pathlib import Path
import hashlib,json,time
import numpy as np
import cv2
CANONICAL=np.array([[192.98138,239.94708],[318.90277,240.1936],[256.63416,314.01935],[201.26117,371.41043],[313.08905,371.15118]],np.float64)
YUNET_SHA='8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4'

def similarity(points):
 points=np.asarray(points,np.float64)
 if points.shape!=(5,2) or not np.isfinite(points).all():raise ValueError('Pontos faciais invalidos.')
 a=[];b=[]
 for (x,y),(u,v) in zip(points,CANONICAL):a.extend([[x,-y,1,0],[y,x,0,1]]);b.extend([u,v])
 values,_,rank,_=np.linalg.lstsq(a,b,rcond=None)
 if rank!=4:raise ValueError('Alinhamento degenerado.')
 s,r,tx,ty=values;matrix=np.array([[s,-r,tx],[r,s,ty]])
 fit=points@matrix[:,:2].T+matrix[:,2]
 if np.sqrt(np.mean((fit-CANONICAL)**2))>18:raise ValueError('Rosto muito inclinado/oculto para esta versao; use close frontal.')
 if not .25<np.hypot(s,r)<15:raise ValueError('Escala facial fora do limite.')
 return matrix

def choose_face(rgb,model):
 if hashlib.sha256(Path(model).read_bytes()).hexdigest()!=YUNET_SHA:raise ValueError('YuNet com checksum diferente.')
 h,w=rgb.shape[:2];scale=min(1.0,960/max(w,h));sw,sh=round(w*scale),round(h*scale)
 small=cv2.resize(rgb,(sw,sh),interpolation=cv2.INTER_AREA)
 detector=cv2.FaceDetectorYN.create(str(model),'',(sw,sh),.85,.3,5000)
 _,rows=detector.detect(cv2.cvtColor(small,cv2.COLOR_RGB2BGR))
 candidates=[]
 if rows is not None:
  for row in rows:
   row=row.copy();row[:14]/=scale;x,y,bw,bh=row[:4]
   if min(bw,bh)<80 or x<0 or y<0 or x+bw>w or y+bh>h:continue
   points=row[4:14].reshape(5,2).astype(np.float64)
   if np.linalg.norm(points[1]-points[0])<25:continue
   if abs(points[1,1]-points[0,1])>abs(points[1,0]-points[0,0])*.65:continue
   try:matrix=similarity(points)
   except ValueError:continue
   candidates.append((float(bw*bh),matrix,points,row))
 if not candidates:raise ValueError('Nenhum rosto frontal grande encontrado. Pause o replay, aproxime o jogador e tente Ctrl+F8 novamente.')
 _,matrix,points,row=max(candidates,key=lambda r:r[0])
 return matrix,{'bbox_xywh':row[:4].tolist(),'confidence':float(row[14]),'landmarks':points.tolist(),'eligible_faces':len(candidates),'selection':'largest frontal face; minimum80px'}

def align(rgb,matrix):
 return cv2.warpAffine(rgb,matrix,(512,512),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_REFLECT_101)

def compose(rgb,restored,matrix):
 if restored.shape!=(512,512,3) or restored.dtype!=np.uint8:raise ValueError('Saida neural invalida.')
 h,w=rgb.shape[:2];inverse=cv2.invertAffineTransform(matrix)
 yy,xx=np.mgrid[0:512,0:512];distance=np.sqrt(((xx-256)/150)**2+((yy-285)/190)**2)
 mask=np.clip((1-distance)/.13,0,1).astype(np.float32)
 face=cv2.warpAffine(restored,inverse,(w,h),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT)
 alpha=cv2.warpAffine(mask,inverse,(w,h),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT)
 rgba=np.dstack((face,np.rint(alpha*255).astype(np.uint8)))
 y,x=np.where(rgba[:,:,3]>0)
 if not len(x):raise ValueError('Mascara facial vazia.')
 roi=[float(x.min()/w),float(y.min()/h),float((x.max()+1)/w),float((y.max()+1)/h)]
 blended=np.rint(rgb.astype(np.float32)*(1-alpha[:,:,None])+face*alpha[:,:,None]).astype(np.uint8)
 return rgba,blended,roi

class Neural:
 def __init__(self,checkpoint,device='cuda'):
  import torch
  from common import sha256,MODEL_SHA
  from standalone_gfpganv1_clean_arch import GFPGANv1Clean
  if device not in ('cuda','cpu'):raise ValueError('Invalid device')
  self.torch=torch;self.device=device
  torch.set_num_threads(2);torch.manual_seed(0)
  if device=='cuda':
   if not torch.cuda.is_available():raise RuntimeError('CUDA indisponivel; nao ha fallback CPU no PES.')
   torch.cuda.set_device(0);prop=torch.cuda.get_device_properties(0)
   torch.cuda.set_per_process_memory_fraction(min(1.,1024**3/prop.total_memory),0)
   torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.backends.cudnn.benchmark=False
   self.check_memory()
  if sha256(checkpoint)!=MODEL_SHA:raise ValueError('Checkpoint GFPGAN diferente do aprovado.')
  m=GFPGANv1Clean(out_size=512,num_style_feat=512,channel_multiplier=2,decoder_load_path=None,fix_decoder=False,num_mlp=8,input_is_latent=True,different_w=True,narrow=1,sft_half=True).eval()
  state=torch.load(checkpoint,map_location='cpu',weights_only=True);m.load_state_dict(state['params_ema'],strict=True);del state
  self.model=m.to(device)
 def check_memory(self):
  if self.device=='cuda':
   free,total=self.torch.cuda.mem_get_info(0)
   if total-free>=5.5*1024**3:raise RuntimeError('Uso global CUDA >=5,5 GiB. Feche aplicativos extras ou reduza a carga do jogo.')
 def infer(self,rgb):
  from contextlib import nullcontext
  t=self.torch;self.check_memory()
  x=(t.from_numpy((rgb.astype(np.float32)/255).transpose(2,0,1)[None])*2-1).contiguous().to(self.device)
  if self.device=='cuda':t.cuda.synchronize();t.cuda.reset_peak_memory_stats()
  start=time.perf_counter()
  with t.inference_mode(),(t.autocast('cuda',dtype=t.float16) if self.device=='cuda' else nullcontext()):
   output=self.model(x,return_rgb=False,randomize_noise=False)[0]
  if self.device=='cuda':t.cuda.synchronize()
  ms=(time.perf_counter()-start)*1000
  if not t.isfinite(output).all().item():raise RuntimeError('GFPGAN produziu NaN/Inf.')
  pixels=np.rint((output[0].float().clamp(-1,1).permute(1,2,0).cpu().numpy()+1)*127.5).astype(np.uint8)
  report={'device':self.device,'precision':'amp' if self.device=='cuda' else 'fp32','forward_wall_ms':ms,'timing_scope':'one forward plus synchronization; excludes detection/alignment/composition/capture/transfers','game_60fps_validated':False}
  if self.device=='cuda':
   self.check_memory();report.update({'gpu':t.cuda.get_device_name(0),'peak_allocated_bytes':t.cuda.max_memory_allocated(),'peak_reserved_bytes':t.cuda.max_memory_reserved()})
  del x,output
  if self.device=='cuda':t.cuda.empty_cache()
  return pixels,report
