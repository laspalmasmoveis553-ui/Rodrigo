import ctypes as c
from ctypes import wintypes as w
from contextlib import contextmanager
from protocol import announcement,decode,HEADER
class Channel:
 def __init__(self,data):
  self.data=data;self.size=announcement(data);self.view=None;self.mapping=None;self.mutex=None
  self.k=c.WinDLL('kernel32',use_last_error=True)
  specs={'OpenFileMappingW':([w.DWORD,w.BOOL,w.LPCWSTR],w.HANDLE),'OpenMutexW':([w.DWORD,w.BOOL,w.LPCWSTR],w.HANDLE),'MapViewOfFile':([w.HANDLE,w.DWORD,w.DWORD,w.DWORD,c.c_size_t],c.c_void_p),'WaitForSingleObject':([w.HANDLE,w.DWORD],w.DWORD),'ReleaseMutex':([w.HANDLE],w.BOOL),'UnmapViewOfFile':([c.c_void_p],w.BOOL),'CloseHandle':([w.HANDLE],w.BOOL)}
  for name,(args,result) in specs.items():getattr(self.k,name).argtypes=args;getattr(self.k,name).restype=result
  try:
   self.mapping=self.k.OpenFileMappingW(0xF001F,False,data['name'])
   self.mutex=self.k.OpenMutexW(0x100001,False,data['name']+'-mutex')
   if not self.mapping or not self.mutex:raise OSError('Canal fechado. Abra o PES com o addon instalado.')
   self.view=self.k.MapViewOfFile(self.mapping,0xF001F,0,0,self.size)
   if not self.view:raise OSError('Falha ao mapear captura.')
  except BaseException:self.close();raise
 @contextmanager
 def locked(self):
  result=self.k.WaitForSingleObject(self.mutex,1000)
  if result not in (0,0x80):raise TimeoutError('Canal ocupado ou encerrado.')
  try:yield
  finally:self.k.ReleaseMutex(self.mutex)
 def header(self):return decode(c.string_at(self.view,64),self.data['width'],self.data['height'])
 def write_header(self,v):c.memmove(self.view,HEADER.pack(*v),64)
 def input(self):return c.string_at(self.view+64,self.data['width']*self.data['height']*4)
 def output(self,b):
  count=self.data['width']*self.data['height']*4
  if len(b)!=count:raise ValueError('Tamanho de saida incorreto.')
  c.memmove(self.view+64+count,b,count)
 def close(self):
  if self.view:self.k.UnmapViewOfFile(self.view);self.view=None
  for name in ['mapping','mutex']:
   h=getattr(self,name,None)
   if h:self.k.CloseHandle(h);setattr(self,name,None)
